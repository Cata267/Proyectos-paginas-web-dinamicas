console.log("hello world");
//suma de dos números.
var n1=2;
var n2=2;
var tot;
tot = n1+n2;
console.log("resultado suma: "+tot);
//multiplicación de dos números
var m1 = 3;
var m2 = 4;
var mult;
mult = m1 * m2;
console.log("resultado multplicacion: "+mult);
//raíz cuadrada
var rcd = Math.sqrt(1244);
var rce = Math.round(rcd);
console.log("raiz cuadrada decimal: "+rcd);
console.log("raiz cuadrada entera: "+rce);
//Números primos
var c = 500;
var j = 2;
var numerosPrimos = [];
for (; j < c; j++) {
  if (primo(j)) {
    numerosPrimos.push(j);
  }
}
console.log(numerosPrimos);
function primo(numero) {
  for (var i = 2; i < numero; i++) {
    if (numero % i === 0) {
      return false;
    }
  }
  return numero !== 1;
}
